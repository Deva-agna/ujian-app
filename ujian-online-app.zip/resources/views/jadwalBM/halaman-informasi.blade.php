@extends('layout.master')

@section('halaman', 'Tambah Mapel')

@section('title','Tambah Mapel')

@section('jadwalBM','active')

@section('konten')

<div class="w-100 text-center">
    <h2 class="mb-1">Halaman Informasi 🕵🏻‍♀️</h2>
    <p class="mb-2">Oops! 😖 Halaman jadwal belajar mengajar tidak ditemukan. Pastikan bahwa tahun ajaran sudah aktiv!</p>
</div>

@endsection